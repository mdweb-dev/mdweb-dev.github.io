<footer class="footer">
	<div class="footer__container">
		footer
	</div>
</footer>
