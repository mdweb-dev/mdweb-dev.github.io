<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="format-detection" content="telephone=no">
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<!-- Styles for frontend -->
<link rel="stylesheet" href="../assets/css/common.css" />


<!--<link rel="stylesheet" href="assets/css/hero.css" />-->
<!-- Styles for backend -->
<!--<link rel="stylesheet" href="assets/css/app.min.css" />-->