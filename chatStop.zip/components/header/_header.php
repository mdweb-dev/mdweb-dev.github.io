<!-- header -->
<header class="header">
	<div class="container">
		<a href="#">
			<picture>
				<img src="../assets/img/cloud-fog-svgrepo-com.svg" alt="" width="200">
			</picture>
		</a>
	</div>
</header>
<!-- end header -->