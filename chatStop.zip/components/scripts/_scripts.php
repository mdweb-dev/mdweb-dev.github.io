<!-- Scripts for frontend -->
<script type='text/javascript' src="../assets/js/common.js"></script>
<!-- Scripts for backend -->
<!--<script type='text/javascript' src="assets/js/app.min.js"></script>-->