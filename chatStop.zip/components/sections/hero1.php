<section class="hero">
    <div class="container">
        <?php include('../components/elements/_product-card.php') ?>
        <?php include('../components/elements/_product-card.php') ?>
        <?php include('../components/elements/_product-card.php') ?>
    </div>
</section>