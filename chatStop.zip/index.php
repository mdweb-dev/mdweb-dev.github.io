<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Test task</title>
    <?php include('components/head/_head.php') ?>
</head>
<body>
<div class="wrapper">
    <main class="main">
        <section class="index-menu">
            <div class="index-menu__container">
                <ul>
                    <li>
                        <a href="pages/animation-1.php">Animation 1</a>
                    </li>
                    <li>
                        <a href="pages/animation-2.php">Animation 2</a>
                    </li>
                </ul>
            </div>
        </section>
    </main>
</div>
</body>
</html>