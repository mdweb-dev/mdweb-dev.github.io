<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
	      content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Animation 2</title>
	<link rel="stylesheet" href="../assets/css/common.min.css">
    <link rel="stylesheet" href="../assets/css/element-interactive_card.min.css">
    <link rel="stylesheet" href="../assets/css/section-interactive.min.css">
	<link rel="stylesheet" href="../assets/css/section-hero_intro.min.css">
	<link rel="stylesheet" href="../assets/css/section-about_company.min.css">
</head>
<body class="animation-2">
<div class="wrapper">

	<main class="main js-trigger">
		<section class="about-company js-about-company">
			<div class="about-company__container">
				<h2 class="about-company__title js-title-section">
					ЛІДЕРИ В УПРАВЛІННІ КОМЕНЦІЙНОЮ
					нерухомістю. З нами активи працюють
					на вас, а не ви на них.
				</h2>
				<div class="about-company__wrapper">
					<div class="about-company__picture">
                        <img src="../assets/img/hero-intro.jpg" alt="intro">
					</div>

					<div class="about-company__main">
						<div class="about-company__count js-company-count">
							<span>200000</span> м²
						</div>

						<div class="about-company__about js-company-about">
							<p>
								В управлінні, які включають понад 100 різних обʼєктів. Намагаємось використати кожен квадратний метр.
							</p>
						</div>
					</div>
				</div>
			</div>

            <div class="about-company__mask">
                <div class="hero-intro__title js-title-intro">
                    <mark>Керуємо</mark>
                    <br>
                    НЕРУХОМІСТЮ
                    <br>
                    щоб ви нудьгували
                </div>
            </div>
		</section>

        <section class="interactive">
            <div class="interactive__container">
                <div class="interactive-card" style="background-image: url('../assets/img/hero-intro.jpg')">
                    <div class="interactive-card__title">
                        Керуємо <br>
                        НЕРУХОМІСТЮ <br>
                        щоб ви нудьгували
                    </div>
                </div>
            </div>
        </section>
	</main>

</div>

<script src="../assets/libs/gsap/SplitText.min.js"></script>
<script src="../assets/js/common.min.js"></script>
<script src="../assets/js/section-animation_2.min.js"></script>
</body>
</html>