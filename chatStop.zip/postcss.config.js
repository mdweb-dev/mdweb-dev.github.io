module.exports = {
  plugins: {
    "autoprefixer": { overrideBrowserslist: ['last 10 versions'], grid: false }
  }
}
